
    //Menu Toggle Script

    $("#menu-toggle").click(function (e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });

    var header = document.getElementById("active-btn");
    var btns = header.getElementsByClassName("btns");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function () {
        var current = document.getElementsByClassName("active");
        current[0].className = current[0].className.replace(" active", "");
        this.className += " active";
      });
    }


    function myFunction(y) {
      var db = document.getElementById("dashboard");
      var nt = document.getElementById("notes");
      var mt = document.getElementById("mockTest");
      var pp = document.getElementById("previPaper");
      var ms = document.getElementById("message");
      var sc = document.getElementById("subscribers");
      var cd = document.getElementById("contactDetail");
      if (`1` === y) {
        db.style.display = "block";
        nt.style.display = "none";
        mt.style.display = "none";
        pp.style.display = "none";
        ms.style.display = "none";
        sc.style.display = "none";
        cd.style.display = "none";
      } else if (`2` === y) {
        db.style.display = "none";
        nt.style.display = "block";
        mt.style.display = "none";
        pp.style.display = "none";
        ms.style.display = "none";
        sc.style.display = "none";
        cd.style.display = "none";
      } else if (`3` === y) {
        db.style.display = "none";
        nt.style.display = "none";
        mt.style.display = "block";
        pp.style.display = "none";
        ms.style.display = "none";
        sc.style.display = "none";
        cd.style.display = "none";
      } else if (`4` === y) {
        db.style.display = "none";
        nt.style.display = "none";
        mt.style.display = "none";
        pp.style.display = "block";
        ms.style.display = "none";
        sc.style.display = "none";
        cd.style.display = "none";
      } else if (`5` === y) {
        db.style.display = "none";
        nt.style.display = "none";
        mt.style.display = "none";
        pp.style.display = "none";
        ms.style.display = "block";
        sc.style.display = "none";
        cd.style.display = "none";
      } else if (`6` === y) {
        db.style.display = "none";
        nt.style.display = "none";
        mt.style.display = "none";
        pp.style.display = "none";
        ms.style.display = "none";
        sc.style.display = "block";
        cd.style.display = "none";
      } else if (`7` === y) {
        db.style.display = "none";
        nt.style.display = "none";
        mt.style.display = "none";
        pp.style.display = "none";
        ms.style.display = "none";
        sc.style.display = "none";
        cd.style.display = "block";
      }
    }

  google.charts.load('current', {'packages':['corechart']});
  google.charts.setOnLoadCallback(drawChart);

  function drawChart() {
    var data = google.visualization.arrayToDataTable([
      ['Year', 'View', 'Subscribers'],
      ['',  10,      20],
      ['',  150,      70],
      ['',  420,       100],
      ['',  640,      340],
      ['',  780,      510]
    ]);

    var options = {
      title: 'Performance',
      curveType: 'function',
      legend: { position: 'bottom' }
    };

    var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

    chart.draw(data, options);
  }