import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/PaperUpload")
@MultipartConfig
public class addPaper extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String name = "Java";
        final Part filePart = request.getPart("pdf");

        InputStream pdfFileBytes = null;
        final PrintWriter writer = response.getWriter();
        try {

            if (!filePart.getContentType().equals("application/pdf")) {
                writer.println("<br/> Invalid File");
                return;
            } else if (filePart.getSize() > 1048576) {
                {
                    writer.println("<br/> File size too big");
                    return;
                }
            }

            pdfFileBytes = filePart.getInputStream();

            final byte[] data = new byte[pdfFileBytes.available()];
            pdfFileBytes.read(data);

            Connection con = null;
            Statement stmt = null;

            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/learningpoint", "root", "root");
            } catch (Exception e) {
                System.out.println(e);
                System.exit(0);
            }

            int success = 0;
            PreparedStatement pstmt = con.prepareStatement("INSERT INTO PREVIPAPER(name, pdf) VALUES(?,?)");
            pstmt.setString(1, name);
            pstmt.setBytes(2, data);
            success = pstmt.executeUpdate();
            if (success >= 1) {
                System.out.println("Stored");
            }
            con.close();

            writer.println("<br/>Successfully Stored");

        } catch (FileNotFoundException fnf) {
            writer.println("You  did not specify a file to upload");
            writer.println("<br/> ERROR: " + fnf.getMessage());

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (pdfFileBytes != null) {
                pdfFileBytes.close();
            }
            if (writer != null) {
                writer.close();
            }
        }
    }
}
